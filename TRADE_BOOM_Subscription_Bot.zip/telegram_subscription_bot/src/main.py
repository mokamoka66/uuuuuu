import os
import sys
import asyncio
import threading
import logging
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory, jsonify
from src.models.user import db
from src.models.subscription import Subscription, PaymentRequest
from src.routes.user import user_bp
from src.telegram_bot import create_bot
from src.scheduler import create_scheduler

# إعداد التسجيل
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))
app.config['SECRET_KEY'] = 'asdf#FGSgvasgf$5$WGT'

# إعداد قاعدة البيانات
app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(os.path.dirname(__file__), 'database', 'app.db')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

# إنشاء الجداول
with app.app_context():
    db.create_all()

# تسجيل المسارات
app.register_blueprint(user_bp, url_prefix='/api')

# معلومات البوت
BOT_TOKEN = "8284508405:AAFZS2a1HCcumV9Sq8zbEDIhfcDQsteCPGQ"
CHANNEL_ID = "@TRADEBOOM"  # يجب تحديث هذا برقم القناة الصحيح

# إنشاء البوت والمجدول
telegram_bot = create_bot(app)
scheduler = create_scheduler(app, BOT_TOKEN, CHANNEL_ID)

# مسارات إضافية لإدارة النظام
@app.route('/api/stats')
def get_stats():
    """إحصائيات النظام"""
    with app.app_context():
        try:
            total_users = Subscription.query.count()
            active_users = Subscription.query.filter_by(is_active=True).count()
            pending_payments = PaymentRequest.query.filter_by(status='pending').count()
            
            return jsonify({
                'total_users': total_users,
                'active_users': active_users,
                'pending_payments': pending_payments,
                'status': 'success'
            })
        except Exception as e:
            return jsonify({'error': str(e), 'status': 'error'}), 500

@app.route('/api/subscriptions')
def get_subscriptions():
    """قائمة الاشتراكات"""
    with app.app_context():
        try:
            subscriptions = Subscription.query.all()
            return jsonify({
                'subscriptions': [sub.to_dict() for sub in subscriptions],
                'status': 'success'
            })
        except Exception as e:
            return jsonify({'error': str(e), 'status': 'error'}), 500

@app.route('/api/health')
def health_check():
    """فحص صحة النظام"""
    return jsonify({
        'status': 'healthy',
        'bot_running': True,
        'scheduler_running': scheduler.running if scheduler else False,
        'database': 'connected'
    })

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    static_folder_path = app.static_folder
    if static_folder_path is None:
        return "Static folder not configured", 404

    if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
        return send_from_directory(static_folder_path, path)
    else:
        index_path = os.path.join(static_folder_path, 'index.html')
        if os.path.exists(index_path):
            return send_from_directory(static_folder_path, 'index.html')
        else:
            return "index.html not found", 404

def run_bot_async():
    """تشغيل البوت في حلقة أحداث منفصلة"""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        loop.run_until_complete(telegram_bot.run_bot())
    except Exception as e:
        logger.error(f"Error running bot: {e}")
    finally:
        loop.close()

if __name__ == '__main__':
    try:
        # بدء المجدول
        scheduler.start()
        logger.info("Scheduler started successfully")
        
        # بدء البوت في خيط منفصل
        bot_thread = threading.Thread(target=run_bot_async, daemon=True)
        bot_thread.start()
        logger.info("Telegram bot started successfully")
        
        # تشغيل Flask
        logger.info("Starting Flask application...")
        app.run(host='0.0.0.0', port=5000, debug=False)
        
    except KeyboardInterrupt:
        logger.info("Shutting down...")
        scheduler.stop()
    except Exception as e:
        logger.error(f"Error starting application: {e}")
        scheduler.stop()

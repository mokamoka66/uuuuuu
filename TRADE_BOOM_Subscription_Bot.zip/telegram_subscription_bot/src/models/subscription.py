from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timedelta
from src.models.user import db

class Subscription(db.Model):
    __tablename__ = 'subscriptions'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, nullable=False, unique=True)
    username = db.Column(db.String(100), nullable=True)
    first_name = db.Column(db.String(100), nullable=True)
    last_name = db.Column(db.String(100), nullable=True)
    start_date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    end_date = db.Column(db.DateTime, nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    payment_amount = db.Column(db.Float, nullable=False, default=29.0)
    payment_status = db.Column(db.String(20), default='pending')  # pending, confirmed, expired
    transaction_hash = db.Column(db.String(100), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def __init__(self, user_id, username=None, first_name=None, last_name=None, 
                 payment_amount=29.0, subscription_days=3):
        self.user_id = user_id
        self.username = username
        self.first_name = first_name
        self.last_name = last_name
        self.payment_amount = payment_amount
        self.start_date = datetime.utcnow()
        self.end_date = self.start_date + timedelta(days=subscription_days)
    
    def is_expired(self):
        return datetime.utcnow() > self.end_date
    
    def days_remaining(self):
        if self.is_expired():
            return 0
        return (self.end_date - datetime.utcnow()).days
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'username': self.username,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'start_date': self.start_date.isoformat(),
            'end_date': self.end_date.isoformat(),
            'is_active': self.is_active,
            'payment_amount': self.payment_amount,
            'payment_status': self.payment_status,
            'transaction_hash': self.transaction_hash,
            'days_remaining': self.days_remaining()
        }

class PaymentRequest(db.Model):
    __tablename__ = 'payment_requests'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, nullable=False)
    amount = db.Column(db.Float, nullable=False, default=29.0)
    wallet_address = db.Column(db.String(100), nullable=False)
    status = db.Column(db.String(20), default='pending')  # pending, confirmed, expired
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    expires_at = db.Column(db.DateTime, nullable=False)
    
    def __init__(self, user_id, amount=29.0, wallet_address="TMhsVFZS2Dy1GXDScJsWiYDrQgXeyKZJUc"):
        self.user_id = user_id
        self.amount = amount
        self.wallet_address = wallet_address
        self.expires_at = datetime.utcnow() + timedelta(hours=1)  # تنتهي صلاحية الطلب خلال ساعة
    
    def is_expired(self):
        return datetime.utcnow() > self.expires_at
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'amount': self.amount,
            'wallet_address': self.wallet_address,
            'status': self.status,
            'created_at': self.created_at.isoformat(),
            'expires_at': self.expires_at.isoformat(),
            'is_expired': self.is_expired()
        }


import os
import sys
import schedule
import time
import threading
import logging
from datetime import datetime
from telegram import Bot

# إعداد المسار
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from src.models.user import db
from src.models.subscription import Subscription
from flask import Flask

logger = logging.getLogger(__name__)

class SubscriptionScheduler:
    def __init__(self, app: Flask, bot_token: str, channel_id: str):
        self.app = app
        self.bot = Bot(token=bot_token)
        self.channel_id = channel_id
        self.running = False
        self.thread = None
    
    def check_expired_subscriptions(self):
        """فحص الاشتراكات المنتهية الصلاحية"""
        with self.app.app_context():
            try:
                # البحث عن الاشتراكات المنتهية الصلاحية
                expired_subscriptions = Subscription.query.filter(
                    Subscription.is_active == True,
                    Subscription.end_date <= datetime.utcnow()
                ).all()
                
                for subscription in expired_subscriptions:
                    try:
                        # إزالة المستخدم من القناة
                        self.remove_user_from_channel(subscription.user_id)
                        
                        # تحديث حالة الاشتراك
                        subscription.is_active = False
                        subscription.payment_status = 'expired'
                        
                        # إرسال إشعار للمستخدم
                        self.send_expiry_notification(subscription.user_id)
                        
                        logger.info(f"Removed expired user {subscription.user_id} from channel")
                        
                    except Exception as e:
                        logger.error(f"Error processing expired subscription {subscription.id}: {e}")
                
                # حفظ التغييرات
                db.session.commit()
                
                if expired_subscriptions:
                    logger.info(f"Processed {len(expired_subscriptions)} expired subscriptions")
                
            except Exception as e:
                logger.error(f"Error checking expired subscriptions: {e}")
                db.session.rollback()
    
    def send_expiry_notifications(self):
        """إرسال تذكيرات قبل انتهاء الاشتراك"""
        with self.app.app_context():
            try:
                # البحث عن الاشتراكات التي ستنتهي خلال 24 ساعة
                tomorrow = datetime.utcnow().replace(hour=23, minute=59, second=59)
                
                expiring_subscriptions = Subscription.query.filter(
                    Subscription.is_active == True,
                    Subscription.end_date <= tomorrow,
                    Subscription.end_date > datetime.utcnow()
                ).all()
                
                for subscription in expiring_subscriptions:
                    try:
                        remaining_hours = int((subscription.end_date - datetime.utcnow()).total_seconds() / 3600)
                        
                        if remaining_hours <= 24 and remaining_hours > 0:
                            self.send_reminder_notification(subscription.user_id, remaining_hours)
                            logger.info(f"Sent reminder to user {subscription.user_id}")
                            
                    except Exception as e:
                        logger.error(f"Error sending reminder to user {subscription.user_id}: {e}")
                
            except Exception as e:
                logger.error(f"Error sending expiry notifications: {e}")
    
    def remove_user_from_channel(self, user_id: int):
        """إزالة المستخدم من القناة"""
        try:
            # محاولة حظر المستخدم ثم إلغاء الحظر (لإزالته من القناة)
            self.bot.ban_chat_member(chat_id=self.channel_id, user_id=user_id)
            self.bot.unban_chat_member(chat_id=self.channel_id, user_id=user_id)
            logger.info(f"Successfully removed user {user_id} from channel")
            
        except Exception as e:
            logger.error(f"Error removing user {user_id} from channel: {e}")
    
    def send_expiry_notification(self, user_id: int):
        """إرسال إشعار انتهاء الاشتراك"""
        try:
            message = """
❌ انتهى اشتراكك في قناة TRADE&BOOM

🔄 لتجديد الاشتراك والعودة للقناة:
• استخدم الأمر /subscribe
• أو اضغط على "اشترك الآن" أدناه

شكراً لك على ثقتك بنا! 🙏
            """
            
            self.bot.send_message(
                chat_id=user_id,
                text=message,
                reply_markup=self.get_renewal_keyboard()
            )
            
        except Exception as e:
            logger.error(f"Error sending expiry notification to user {user_id}: {e}")
    
    def send_reminder_notification(self, user_id: int, hours_remaining: int):
        """إرسال تذكير قبل انتهاء الاشتراك"""
        try:
            message = f"""
⏰ تذكير: سينتهي اشتراكك خلال {hours_remaining} ساعة

🔄 لتجديد الاشتراك:
• استخدم الأمر /subscribe
• أو اضغط على "جدد الاشتراك" أدناه

لا تفوت المحتوى الحصري! 📈
            """
            
            self.bot.send_message(
                chat_id=user_id,
                text=message,
                reply_markup=self.get_renewal_keyboard()
            )
            
        except Exception as e:
            logger.error(f"Error sending reminder to user {user_id}: {e}")
    
    def get_renewal_keyboard(self):
        """إنشاء لوحة مفاتيح التجديد"""
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup
        
        keyboard = [
            [InlineKeyboardButton("🔄 جدد الاشتراك", callback_data="subscribe")],
            [InlineKeyboardButton("📊 حالة الاشتراك", callback_data="status")]
        ]
        return InlineKeyboardMarkup(keyboard)
    
    def cleanup_old_records(self):
        """تنظيف السجلات القديمة"""
        with self.app.app_context():
            try:
                # حذف طلبات الدفع المنتهية الصلاحية (أكثر من 24 ساعة)
                from src.models.subscription import PaymentRequest
                
                old_payment_requests = PaymentRequest.query.filter(
                    PaymentRequest.expires_at <= datetime.utcnow()
                ).all()
                
                for request in old_payment_requests:
                    db.session.delete(request)
                
                # حذف الاشتراكات المنتهية (أكثر من 30 يوم)
                from datetime import timedelta
                old_date = datetime.utcnow() - timedelta(days=30)
                
                old_subscriptions = Subscription.query.filter(
                    Subscription.is_active == False,
                    Subscription.end_date <= old_date
                ).all()
                
                for subscription in old_subscriptions:
                    db.session.delete(subscription)
                
                db.session.commit()
                
                if old_payment_requests or old_subscriptions:
                    logger.info(f"Cleaned up {len(old_payment_requests)} payment requests and {len(old_subscriptions)} old subscriptions")
                
            except Exception as e:
                logger.error(f"Error cleaning up old records: {e}")
                db.session.rollback()
    
    def setup_schedule(self):
        """إعداد المهام المجدولة"""
        # فحص الاشتراكات المنتهية كل 30 دقيقة
        schedule.every(30).minutes.do(self.check_expired_subscriptions)
        
        # إرسال تذكيرات كل 6 ساعات
        schedule.every(6).hours.do(self.send_expiry_notifications)
        
        # تنظيف السجلات القديمة يومياً في الساعة 3 صباحاً
        schedule.every().day.at("03:00").do(self.cleanup_old_records)
        
        logger.info("Scheduled tasks configured successfully")
    
    def run_scheduler(self):
        """تشغيل المجدول"""
        self.setup_schedule()
        self.running = True
        
        logger.info("Scheduler started")
        
        while self.running:
            try:
                schedule.run_pending()
                time.sleep(60)  # فحص كل دقيقة
            except Exception as e:
                logger.error(f"Error in scheduler loop: {e}")
                time.sleep(60)
    
    def start(self):
        """بدء المجدول في خيط منفصل"""
        if not self.running:
            self.thread = threading.Thread(target=self.run_scheduler, daemon=True)
            self.thread.start()
            logger.info("Scheduler thread started")
    
    def stop(self):
        """إيقاف المجدول"""
        self.running = False
        if self.thread:
            self.thread.join(timeout=5)
        logger.info("Scheduler stopped")

def create_scheduler(app: Flask, bot_token: str, channel_id: str) -> SubscriptionScheduler:
    """إنشاء مجدول المهام"""
    return SubscriptionScheduler(app, bot_token, channel_id)


import os
import sys
import logging
import asyncio
from datetime import datetime, timedelta
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes
import requests
import json

# إعداد المسار
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from src.models.user import db
from src.models.subscription import Subscription, PaymentRequest
from flask import Flask

# إعداد التسجيل
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# معلومات البوت والقناة
BOT_TOKEN = "8284508405:AAFZS2a1HCcumV9Sq8zbEDIhfcDQsteCPGQ"
CHANNEL_ID = "@TRADEBOOM"  # يجب تحديث هذا برقم القناة الصحيح
USDT_WALLET = "TMhsVFZS2Dy1GXDScJsWiYDrQgXeyKZJUc"
SUBSCRIPTION_PRICE = 29.0
SUBSCRIPTION_DAYS = 3

class TelegramBot:
    def __init__(self, app: Flask):
        self.app = app
        self.application = Application.builder().token(BOT_TOKEN).build()
        self.setup_handlers()
    
    def setup_handlers(self):
        """إعداد معالجات الأوامر"""
        self.application.add_handler(CommandHandler("start", self.start_command))
        self.application.add_handler(CommandHandler("subscribe", self.subscribe_command))
        self.application.add_handler(CommandHandler("status", self.status_command))
        self.application.add_handler(CommandHandler("help", self.help_command))
        self.application.add_handler(CallbackQueryHandler(self.button_callback))
        self.application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, self.handle_message))
    
    async def start_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """معالج أمر /start"""
        user = update.effective_user
        
        welcome_text = f"""
🌟 مرحباً بك في بوت قناة TRADE&BOOM! 🌟

مرحباً {user.first_name}! 👋

📈 للوصول إلى محتوى القناة الحصري، تحتاج إلى اشتراك مدفوع.

💰 سعر الاشتراك: {SUBSCRIPTION_PRICE} USDT
⏰ مدة الاشتراك: {SUBSCRIPTION_DAYS} أيام

🔹 ميزات الاشتراك:
• الوصول الكامل لقناة TRADE&BOOM
• تحليلات حصرية للأسواق
• إشارات تداول يومية
• دعم فني مباشر

اضغط على "اشترك الآن" للبدء! 👇
        """
        
        keyboard = [
            [InlineKeyboardButton("🚀 اشترك الآن", callback_data="subscribe")],
            [InlineKeyboardButton("📊 حالة الاشتراك", callback_data="status")],
            [InlineKeyboardButton("❓ المساعدة", callback_data="help")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.message.reply_text(welcome_text, reply_markup=reply_markup)
    
    async def subscribe_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """معالج أمر /subscribe"""
        await self.handle_subscription(update, context)
    
    async def handle_subscription(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """معالجة طلب الاشتراك"""
        user = update.effective_user
        
        with self.app.app_context():
            # التحقق من وجود اشتراك نشط
            existing_subscription = Subscription.query.filter_by(
                user_id=user.id, 
                is_active=True
            ).first()
            
            if existing_subscription and not existing_subscription.is_expired():
                remaining_days = existing_subscription.days_remaining()
                await update.effective_message.reply_text(
                    f"✅ لديك اشتراك نشط بالفعل!\n"
                    f"⏰ الوقت المتبقي: {remaining_days} يوم/أيام\n"
                    f"📅 ينتهي في: {existing_subscription.end_date.strftime('%Y-%m-%d %H:%M')}"
                )
                return
            
            # إنشاء طلب دفع جديد
            payment_request = PaymentRequest(
                user_id=user.id,
                amount=SUBSCRIPTION_PRICE,
                wallet_address=USDT_WALLET
            )
            
            db.session.add(payment_request)
            db.session.commit()
            
            payment_text = f"""
💳 تفاصيل الدفع:

💰 المبلغ: {SUBSCRIPTION_PRICE} USDT (TRC20)
🏦 عنوان المحفظة:
`{USDT_WALLET}`

⚠️ تعليمات مهمة:
1️⃣ أرسل المبلغ بالضبط: {SUBSCRIPTION_PRICE} USDT
2️⃣ استخدم شبكة TRC20 فقط
3️⃣ انتظر تأكيد المعاملة (عادة 1-3 دقائق)
4️⃣ سيتم تفعيل اشتراكك تلقائياً

⏰ صالح لمدة ساعة واحدة من الآن

بعد إرسال المبلغ، اضغط "تحقق من الدفع" 👇
            """
            
            keyboard = [
                [InlineKeyboardButton("🔍 تحقق من الدفع", callback_data=f"check_payment_{payment_request.id}")],
                [InlineKeyboardButton("❌ إلغاء", callback_data="cancel")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await update.effective_message.reply_text(
                payment_text, 
                reply_markup=reply_markup,
                parse_mode='Markdown'
            )
    
    async def status_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """معالج أمر /status"""
        user = update.effective_user
        
        with self.app.app_context():
            subscription = Subscription.query.filter_by(
                user_id=user.id,
                is_active=True
            ).first()
            
            if subscription and not subscription.is_expired():
                remaining_days = subscription.days_remaining()
                status_text = f"""
✅ حالة الاشتراك: نشط

👤 المستخدم: {user.first_name}
💰 المبلغ المدفوع: {subscription.payment_amount} USDT
📅 تاريخ البداية: {subscription.start_date.strftime('%Y-%m-%d %H:%M')}
📅 تاريخ الانتهاء: {subscription.end_date.strftime('%Y-%m-%d %H:%M')}
⏰ الوقت المتبقي: {remaining_days} يوم/أيام

🔗 رابط القناة: {CHANNEL_ID}
                """
            else:
                status_text = """
❌ حالة الاشتراك: غير نشط

لا يوجد لديك اشتراك نشط حالياً.
اضغط "اشترك الآن" للحصول على الوصول للقناة! 👇
                """
                
            keyboard = [
                [InlineKeyboardButton("🚀 اشترك الآن", callback_data="subscribe")],
                [InlineKeyboardButton("🏠 القائمة الرئيسية", callback_data="main_menu")]
            ]
            reply_markup = InlineKeyboardMarkup(keyboard)
            
            await update.effective_message.reply_text(status_text, reply_markup=reply_markup)
    
    async def help_command(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """معالج أمر /help"""
        help_text = """
🆘 مساعدة بوت TRADE&BOOM

📋 الأوامر المتاحة:
• /start - بدء البوت والقائمة الرئيسية
• /subscribe - الاشتراك في القناة
• /status - عرض حالة الاشتراك
• /help - عرض هذه المساعدة

💳 طريقة الدفع:
1. اختر "اشترك الآن"
2. أرسل {SUBSCRIPTION_PRICE} USDT إلى المحفظة المحددة
3. انتظر التأكيد التلقائي
4. ستتم إضافتك للقناة فوراً

⚠️ ملاحظات مهمة:
• استخدم شبكة TRC20 فقط
• أرسل المبلغ بالضبط
• لا ترسل من منصات التداول مباشرة

📞 للدعم: تواصل مع إدارة القناة
        """
        
        keyboard = [
            [InlineKeyboardButton("🚀 اشترك الآن", callback_data="subscribe")],
            [InlineKeyboardButton("🏠 القائمة الرئيسية", callback_data="main_menu")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await update.effective_message.reply_text(help_text, reply_markup=reply_markup)
    
    async def button_callback(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """معالج أزرار الكيبورد"""
        query = update.callback_query
        await query.answer()
        
        if query.data == "subscribe":
            await self.handle_subscription(update, context)
        elif query.data == "status":
            await self.status_command(update, context)
        elif query.data == "help":
            await self.help_command(update, context)
        elif query.data == "main_menu":
            await self.start_command(update, context)
        elif query.data.startswith("check_payment_"):
            payment_id = int(query.data.split("_")[2])
            await self.check_payment(update, context, payment_id)
        elif query.data == "cancel":
            await query.edit_message_text("❌ تم إلغاء العملية.")
    
    async def check_payment(self, update: Update, context: ContextTypes.DEFAULT_TYPE, payment_id: int):
        """التحقق من الدفع"""
        user = update.effective_user
        
        with self.app.app_context():
            payment_request = PaymentRequest.query.get(payment_id)
            
            if not payment_request or payment_request.user_id != user.id:
                await update.effective_message.reply_text("❌ طلب دفع غير صحيح.")
                return
            
            if payment_request.is_expired():
                await update.effective_message.reply_text("⏰ انتهت صلاحية طلب الدفع. يرجى إنشاء طلب جديد.")
                return
            
            # هنا يجب إضافة منطق التحقق من المعاملة على شبكة TRON
            # للتبسيط، سنفترض أن الدفع تم تأكيده
            
            # محاكاة التحقق من الدفع
            payment_confirmed = await self.verify_tron_payment(payment_request.wallet_address, payment_request.amount)
            
            if payment_confirmed:
                # إنشاء اشتراك جديد
                subscription = Subscription(
                    user_id=user.id,
                    username=user.username,
                    first_name=user.first_name,
                    last_name=user.last_name,
                    payment_amount=payment_request.amount,
                    subscription_days=SUBSCRIPTION_DAYS
                )
                subscription.payment_status = 'confirmed'
                
                # تحديث حالة طلب الدفع
                payment_request.status = 'confirmed'
                
                db.session.add(subscription)
                db.session.commit()
                
                # إضافة المستخدم للقناة
                await self.add_user_to_channel(user.id)
                
                success_text = f"""
✅ تم تأكيد الدفع بنجاح!

🎉 مرحباً بك في قناة TRADE&BOOM!
⏰ مدة الاشتراك: {SUBSCRIPTION_DAYS} أيام
📅 ينتهي في: {subscription.end_date.strftime('%Y-%m-%d %H:%M')}

🔗 رابط القناة: {CHANNEL_ID}

يمكنك الآن الوصول لجميع المحتويات الحصرية! 🚀
                """
                
                await update.effective_message.reply_text(success_text)
            else:
                await update.effective_message.reply_text(
                    "⏳ لم يتم العثور على المعاملة بعد.\n"
                    "يرجى المحاولة مرة أخرى خلال دقائق قليلة.\n"
                    "تأكد من إرسال المبلغ الصحيح على شبكة TRC20."
                )
    
    async def verify_tron_payment(self, wallet_address: str, expected_amount: float) -> bool:
        """التحقق من الدفع على شبكة TRON"""
        try:
            from src.tron_payment import verify_usdt_payment
            
            # التحقق من وجود دفعة USDT
            payment_info = verify_usdt_payment(wallet_address, expected_amount)
            
            if payment_info:
                logger.info(f"Payment verified: {payment_info['transaction_hash']}")
                return True
            else:
                logger.info(f"No payment found for {wallet_address} with amount {expected_amount}")
                return False
                
        except Exception as e:
            logger.error(f"Error verifying payment: {e}")
            return False
    
    async def add_user_to_channel(self, user_id: int):
        """إضافة المستخدم للقناة"""
        try:
            # إنشاء رابط دعوة للمستخدم
            invite_link = await self.application.bot.create_chat_invite_link(
                chat_id=CHANNEL_ID,
                member_limit=1,
                expire_date=datetime.utcnow() + timedelta(days=SUBSCRIPTION_DAYS)
            )
            
            # إرسال رابط الدعوة للمستخدم
            await self.application.bot.send_message(
                chat_id=user_id,
                text=f"🔗 رابط الانضمام للقناة:\n{invite_link.invite_link}\n\n"
                     f"⚠️ هذا الرابط صالح لمدة {SUBSCRIPTION_DAYS} أيام فقط."
            )
            
        except Exception as e:
            logger.error(f"Error adding user to channel: {e}")
    
    async def handle_message(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """معالج الرسائل العامة"""
        await update.message.reply_text(
            "👋 مرحباً! استخدم /start لعرض القائمة الرئيسية أو /help للمساعدة."
        )
    
    async def run_bot(self):
        """تشغيل البوت"""
        await self.application.initialize()
        await self.application.start()
        await self.application.updater.start_polling()
    
    async def stop_bot(self):
        """إيقاف البوت"""
        await self.application.updater.stop()
        await self.application.stop()
        await self.application.shutdown()

# دالة لإنشاء وتشغيل البوت
def create_bot(app: Flask) -> TelegramBot:
    return TelegramBot(app)


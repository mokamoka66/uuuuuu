import requests
import json
import logging
from datetime import datetime, timedelta
from typing import Optional, Dict, List

logger = logging.getLogger(__name__)

class TronPaymentVerifier:
    """فئة للتحقق من مدفوعات USDT على شبكة TRON"""
    
    def __init__(self):
        # استخدام TronGrid API (مجاني)
        self.api_base = "https://api.trongrid.io"
        self.usdt_contract = "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t"  # عقد USDT على TRON
        
    def get_account_transactions(self, address: str, limit: int = 50) -> List[Dict]:
        """الحصول على معاملات الحساب"""
        try:
            url = f"{self.api_base}/v1/accounts/{address}/transactions/trc20"
            params = {
                'limit': limit,
                'contract_address': self.usdt_contract
            }
            
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            return data.get('data', [])
            
        except Exception as e:
            logger.error(f"Error fetching transactions for {address}: {e}")
            return []
    
    def verify_payment(self, wallet_address: str, expected_amount: float, 
                      time_window_hours: int = 2) -> Optional[Dict]:
        """
        التحقق من وجود دفعة USDT للمحفظة المحددة
        
        Args:
            wallet_address: عنوان المحفظة المستقبلة
            expected_amount: المبلغ المتوقع بالـ USDT
            time_window_hours: نافذة زمنية للبحث (بالساعات)
            
        Returns:
            معلومات المعاملة إذا تم العثور عليها، None إذا لم توجد
        """
        try:
            transactions = self.get_account_transactions(wallet_address)
            
            # حساب الوقت المحدد للبحث
            cutoff_time = datetime.utcnow() - timedelta(hours=time_window_hours)
            cutoff_timestamp = int(cutoff_time.timestamp() * 1000)
            
            for tx in transactions:
                try:
                    # التحقق من أن المعاملة واردة (to = wallet_address)
                    if tx.get('to') != wallet_address:
                        continue
                    
                    # التحقق من التوقيت
                    tx_timestamp = tx.get('block_timestamp', 0)
                    if tx_timestamp < cutoff_timestamp:
                        continue
                    
                    # التحقق من المبلغ (USDT له 6 خانات عشرية)
                    amount_raw = int(tx.get('value', '0'))
                    amount_usdt = amount_raw / 1000000  # تحويل من الوحدة الأساسية
                    
                    # التحقق من تطابق المبلغ (مع هامش خطأ صغير)
                    if abs(amount_usdt - expected_amount) < 0.01:
                        return {
                            'transaction_hash': tx.get('transaction_id'),
                            'amount': amount_usdt,
                            'from_address': tx.get('from'),
                            'to_address': tx.get('to'),
                            'timestamp': tx_timestamp,
                            'block_number': tx.get('block'),
                            'confirmed': True
                        }
                        
                except Exception as e:
                    logger.error(f"Error processing transaction: {e}")
                    continue
            
            return None
            
        except Exception as e:
            logger.error(f"Error verifying payment: {e}")
            return None
    
    def get_transaction_details(self, tx_hash: str) -> Optional[Dict]:
        """الحصول على تفاصيل معاملة محددة"""
        try:
            url = f"{self.api_base}/v1/transactions/{tx_hash}"
            
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            
            return response.json()
            
        except Exception as e:
            logger.error(f"Error fetching transaction details for {tx_hash}: {e}")
            return None
    
    def is_transaction_confirmed(self, tx_hash: str, min_confirmations: int = 1) -> bool:
        """التحقق من تأكيد المعاملة"""
        try:
            tx_details = self.get_transaction_details(tx_hash)
            
            if not tx_details:
                return False
            
            # في TRON، إذا كانت المعاملة موجودة في البلوك فهي مؤكدة
            return tx_details.get('ret', [{}])[0].get('contractRet') == 'SUCCESS'
            
        except Exception as e:
            logger.error(f"Error checking confirmation for {tx_hash}: {e}")
            return False
    
    def format_amount(self, amount_raw: str) -> float:
        """تحويل المبلغ من الصيغة الخام إلى USDT"""
        try:
            return int(amount_raw) / 1000000
        except:
            return 0.0

# مثيل عام للاستخدام
tron_verifier = TronPaymentVerifier()

def verify_usdt_payment(wallet_address: str, expected_amount: float) -> Optional[Dict]:
    """دالة مساعدة للتحقق من دفع USDT"""
    return tron_verifier.verify_payment(wallet_address, expected_amount)

def check_transaction_status(tx_hash: str) -> bool:
    """دالة مساعدة للتحقق من حالة المعاملة"""
    return tron_verifier.is_transaction_confirmed(tx_hash)

